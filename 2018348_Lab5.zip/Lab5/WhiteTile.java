
public class WhiteTile extends Tile {
    @Override
    protected void move() throws SnakeBiteException {

    }
}
