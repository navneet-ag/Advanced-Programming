
public class SnakeBiteException extends Exception {
    public SnakeBiteException(String message)
    {
        super(message);
    }
}

