
public class VultureBiteException extends Exception {
    public VultureBiteException(String message)
    {
        super(message);
    }
}