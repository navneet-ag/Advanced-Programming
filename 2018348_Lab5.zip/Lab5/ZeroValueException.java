
public class ZeroValueException extends Exception{
    ZeroValueException(String message)
    {
        super(message);
    }
}
