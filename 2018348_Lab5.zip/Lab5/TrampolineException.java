
public class TrampolineException extends Exception {
        public TrampolineException(String message)
        {
            super(message);
        }
    }

