
public class CricketBiteException extends Exception {
    public CricketBiteException(String message)
    {
        super(message);
    }
}