

public class NegativeValueException extends Exception {
    NegativeValueException(String message)
    {
        super(message);
    }
}
