
public class GameWinnerException extends Exception {
    public GameWinnerException (String message)
    {
        super(message);
    }
}
